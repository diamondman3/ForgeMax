package com.tildenprep.derpmod;

import net.minecraft.item.Item;

/**
 * Created by kenny on 3/19/14.
 */

public class GenericItem extends Item {

    public GenericItem() {
        super();
    }

}
