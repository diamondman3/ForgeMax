package com.tildenprep.derpmod.client;

import com.tildenprep.derpmod.CommonProxy;

/**
 * Created by kenny on 5/21/14.
 */
public class ClientProxy extends CommonProxy {

    @Override
    public void registerRenderers() {
        // This is for rendering entities and so forth later on
    }

}
