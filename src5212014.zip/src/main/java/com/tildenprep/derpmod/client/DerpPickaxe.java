package com.tildenprep.derpmod.client;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;

/**
 * Created by kenny on 4/2/14.
 */
public class DerpPickaxe extends ItemPickaxe {


    public DerpPickaxe(Item.ToolMaterial material){
        super(material);
        setCreativeTab(CreativeTabs.tabTools);
        setMaxStackSize(1);
        setUnlocalizedName("derpPickaxe");
        setTextureName("derpmod:derpPickaxe");

    }
}
