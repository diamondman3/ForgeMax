package com.tildenprep.derpmod.client;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;

/**
 * Created by kenny on 4/9/14.
 */
public class DerpAxe extends ItemAxe {

    public DerpAxe(Item.ToolMaterial material){
        super(material);
        setCreativeTab(CreativeTabs.tabTools);
        setMaxStackSize(1);
        setUnlocalizedName("derpAxe");
        setTextureName("derpmod:derpAxe");

    }
}
