package com.tildenprep.derpmod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

/**
 * Created by kenny on 3/19/14.
 */
public class DerpIngot extends Item {

    public DerpIngot(){
        super();
        setCreativeTab(CreativeTabs.tabMaterials);
        setMaxStackSize(64);
        setUnlocalizedName("derpIngot");
        setTextureName("derpmod:derpIngot");
    }
}
