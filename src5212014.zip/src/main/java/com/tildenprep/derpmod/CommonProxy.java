package com.tildenprep.derpmod;

/**
 * Created by kenny on 5/21/14.
 */
public class CommonProxy {

    public void registerRenderers() {
        // Nothing here as the server doesn't render graphics or entities!
    }
}
